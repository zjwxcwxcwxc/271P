import java.util.*;

public class MyAI extends Agent {
    private static final int SIZE = 9;
    private Pos pos = new Pos(0, 0);
    private Dir dir = Dir.Right;
    private Grid[][] board = new Grid[SIZE][SIZE];
    private LinkedList<Pos> frontier = new LinkedList<>();
    private LinkedList<K> kb = new LinkedList<>();
    private int rightBoundary = 7;
    private int upBoundary = 7;
    private boolean foundWumps = false;
    private int wumpsX = -1;
    private int wumpsY = -1;
    private boolean wumpusAlive = true;
    private boolean shoot = false;
	private boolean justShoot = false;
	private boolean hasArrow = true;

    private boolean find = false;
    private boolean goHome = false;

    private class Pos {
        int x;
        int y;

        Pos(int x, int y) {
            this.x = x;
            this.y = y;
        }

        @Override
        public String toString() {
            return "(" + x + "," + y + ")";
        }
    }

    private enum Dir {
        Up, Down, Left, Right
    }
	
	private enum Info {
		NoW, NoP, NoS, NoB, S, B
    }
    
    private class K {
    	int x, y;
    	Info info;
    	
    	K(int x, int y, Info info) {
    		this.x = x;
    		this.y = y;
    		this.info = info;
    	}
    }
	
    public MyAI() {
        // ======================================================================
        // YOUR CODE BEGINS
        // ======================================================================
		for (int i = 0; i < SIZE; i++)
			for (int j = 0; j < SIZE; j++) {
				board[i][j] = new Grid();
				board[i][j].x = i;
				board[i][j].y = j;
			}
		
        // ======================================================================
        // YOUR CODE ENDS
        // ======================================================================
    }

    public Action getAction
            (
                    boolean stench,
                    boolean breeze,
                    boolean glitter,
                    boolean bump,
                    boolean scream
            ) {
        // ======================================================================
        // YOUR CODE BEGINS
        // ======================================================================
        // uncomment printGrid(board size) to debug
        //printGrid(rightBoundary < upBoundary ? upBoundary : rightBoundary);


        if (exploreAllButNoGold()) {
            goHome = true;
        }

        if (bump) {
            if (dir == Dir.Right) {
                pos.x--;
                rightBoundary = pos.x;
            } else if (dir == Dir.Up) {
                pos.y--;
                upBoundary = pos.y;
            }
            clearInvalidPos();
        }
        if (goHome) {
            markGrid(stench && wumpusAlive, breeze);
            return goHome();
        }
        if (glitter) {
            find = true;
            goHome = true;
            return grabGold();
        }
        if (breeze) {
            if (pos.x == 0 && pos.y == 0)
                return Action.CLIMB;
        }
        if (stench && wumpusAlive) {
            if (pos.x == 0 && pos.y == 0) {
                return Action.CLIMB;

            }
        }
		
        update(stench, breeze);
        markGrid(stench && wumpusAlive, breeze);
        //printGrid(rightBoundary < upBoundary ? upBoundary : rightBoundary);
        addToFrontier();
        return goToNextFrontier();
        // ======================================================================
        // YOUR CODE ENDS
        // ======================================================================
    }

    // ======================================================================
    // YOUR CODE BEGINS
    // ======================================================================

    private void update(boolean stench, boolean breeze) {
    	// pushLocalK pushes NoS/S, NoB/B, NoW, NoP,
    	pushLocalK(stench, breeze);
    	
    	while (!kb.isEmpty()) {
    		K k = kb.poll();
    		process(k);
    	}
    }
    	

    private void markGrid(boolean S, boolean B) {
        int x;
        int y;
        int visited = 0;
        if (board[pos.x][pos.y] != null) {
            visited = board[pos.x][pos.y].visited;
        }
        updateGrid(pos.x, pos.y, visited+1, S, B, true);
        int[][] dirs = {{0, -1}, {0, 1}, {-1, 0}, {1, 0}};
        for (int[] curDir : dirs) {
            x = pos.x + curDir[0];
            y = pos.y + curDir[1];
            if (x >= 0 && x <= SIZE && y >= 0 && y <= SIZE) {
                visited = 0;
                if (board[x][y] != null) visited = board[x][y].visited;
                updateGrid(x, y, visited, S, B, false);
            }
        }
    }

    private void updateGrid(int x, int y, int visited, boolean S, boolean B, boolean self) {
        Grid cur;
        if (board[x][y] == null)
            cur = new Grid();
        else
            cur = board[x][y];
        cur.x = x;
        cur.y = y;
        cur.visited = visited;
        if (self) {
            cur.s = S;
            cur.b = B;
        }
        if (S) {
            if (cur.w != 0 && !foundWumps) {
                if (cur.w == -1)
                    cur.w = 1;
                else if (!cur.usedS) {
                    if (cur.w < 1)cur.w++;
//                        if (stenchAndBreezeCount()[0] >= 2) {
//                            removeSpeciousWumps();
//                        }
                }
            }
        }
        if (B && cur.p != 0) {
            if (cur.p == -1)
                cur.p = 1;
            else if (!cur.usedB) {
                if (cur.p < 1)cur.p++;
            }
        }
        if (!S) {
            cur.w = 0;
        }
        if (S && foundWumps && cur.w < 2) {
            cur.w = 0;
        }
        if (!B) {
            cur.p = 0;
        }

        board[x][y] = cur;

    }
	
		
		
    
    private void process(K k) {
		// process one knowledge accordingly
    	switch(k.info) {
    	case NoW:
    		NoW(k);
    		break;
		case B:
			B(k);
			break;
		case NoB:
			NoB(k);
			break;
		case NoP:
			NoP(k);
			break;
		case NoS:
			NoS(k);
			break;
		case S:
			S(k);
			break;
    	}
		
	}

	private void S(K k) {
		int x = k.x, y = k.y;
		board[x][y].w = 0;
		board[x][y].s = true;
		if (valid(x-1, y) && board[x-1][y].w == -1) board[x-1][y].w = 1;
		if (valid(x+1, y) && board[x+1][y].w == -1) board[x+1][y].w = 1;
		if (valid(x, y-1) && board[x][y-1].w == -1) board[x][y-1].w = 1;
		if (valid(x, y+1) && board[x][y+1].w == -1) board[x][y+1].w = 1;
		for (int i = 0; i < rightBoundary; i++)
			for (int j = 0; j < upBoundary; j++)
				if (valid(i, j) && board[i][j].s == true) s3(i, j);
				else if (valid(i, j) && board[i][j].s == false) sTag(i, j);
	}

	private void NoS(K k) {
		int x = k.x, y = k.y;
		if (valid(x-1, y) && board[x-1][y].w != 0) pushNoW(x-1, y);
		if (valid(x+1, y) && board[x+1][y].w != 0) pushNoW(x+1, y);
		if (valid(x, y-1) && board[x][y-1].w != 0) pushNoW(x, y-1);
		if (valid(x, y+1) && board[x][y+1].w != 0) pushNoW(x, y+1);
	}

	private void NoP(K k) {
		int x = k.x, y = k.y;
		board[x][y].p = 0;
		for (int i = 0; i < rightBoundary; i++)
			for (int j = 0; j < upBoundary; j++)
				if (valid(i, j) && board[i][j].b == true) b3(i, j);
		
	}

	private void NoB(K k) {
		int x = k.x, y = k.y;
		if (valid(x-1, y) && board[x-1][y].p != 0) pushNoP(x-1, y);
		if (valid(x+1, y) && board[x+1][y].p != 0) pushNoP(x+1, y);
		if (valid(x, y-1) && board[x][y-1].p != 0) pushNoP(x, y-1);
		if (valid(x, y+1) && board[x][y+1].p != 0) pushNoP(x, y+1);		
	}

	private void pushNoP(int i, int j) {
		K k = new K(i, j, Info.NoP);
		kb.offer(k);
		
	}

	private void B(K k) {
		int x = k.x, y = k.y;
		board[x][y].p = 0;
		board[x][y].b = true;
		if (valid(x-1, y) && board[x-1][y].p == -1) board[x-1][y].p = 1;
		if (valid(x+1, y) && board[x+1][y].p == -1) board[x+1][y].p = 1;
		if (valid(x, y-1) && board[x][y-1].p == -1) board[x][y-1].p = 1;
		if (valid(x, y+1) && board[x][y+1].p == -1) board[x][y+1].p = 1;
		for (int i = 0; i < rightBoundary; i++)
			for (int j = 0; j < upBoundary; j++)
				if (valid(i, j) && board[i][j].b == true) b3(i, j);
	}

	private void NoW(K k) {
		// 
		int x = k.x, y = k.y;
		board[x][y].w = 0;
		for (int i = 0; i < rightBoundary; i++)
			for (int j = 0; j < upBoundary; j++)
				if (valid(i, j) && board[i][j].s == true) s3(i, j);
				else if (valid(i, j) && board[i][j].s == false) sTag(i, j);
	}

	private void pushNoW(int x, int y) {
		// push 4 directions as NoW as long as valid grid
		K k = new K(x, y, Info.NoW);
		kb.offer(k);

	}

	private void pushLocalK(boolean stench, boolean breeze) {
		if (board[pos.x][pos.y].visited == 0) {
			K k1 = new K(pos.x, pos.y, Info.NoW);
			kb.offer(k1);
			K k2 = new K(pos.x, pos.y, Info.NoP);
			kb.offer(k2);
			if (stench) {
				K k3 = new K(pos.x, pos.y, Info.S);
				kb.offer(k3);
			} else {
				K k3 = new K(pos.x, pos.y, Info.NoS);
				kb.offer(k3);				
			}
			if (breeze) {
				K k4 = new K(pos.x, pos.y, Info.B);
				kb.offer(k4);
			} else {
				K k4 = new K(pos.x, pos.y, Info.NoB);
				kb.offer(k4);
			}
		}
	}

    public void printGrid(int size) {
        String[][] printGrid = new String[SIZE][SIZE];
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                int x = i;
                int y = SIZE - 1 - j;
                if (board[i][j] == null) {
                    printGrid[y][x] = "unvist";
                } else {
                    printGrid[y][x] = "w"+board[i][j].w+"p"+board[i][j].p+"v"+board[i][j].visited;
                }
            }
        }
        System.out.println("----------------------------------------------");
        for (int i = SIZE - size; i < SIZE; i++) {
            for (int j = 0; j < size; j++) {
                System.out.print(printGrid[i][j]+"\t");
            }
            System.out.println("");
        }
        System.out.println("----------------------------------------------");
    }
    
    
    private void s3(int x, int y) {
    	boolean up, down, left, right;
    	int cnt = 0;
    	up = down = left = right = false;
    	if ((left = checkWumpus(x-1, y)) == false) cnt++;
    	if ((right = checkWumpus(x+1, y)) == false) cnt++;
    	if ((down = checkWumpus(x, y-1)) == false) cnt++;
    	if ((up = checkWumpus(x, y+1)) == false) cnt++;
    	
    	if (cnt == 3) {
    		if (left) declareWumpus(x-1, y);
    		if (right) declareWumpus(x+1, y);
    		if (down) declareWumpus(x, y-1);
    		if (up) declareWumpus(x, y+1);    		
    	}
    	
    }
    
    private void b3(int x, int y) {
    	boolean up, down, left, right;
    	int cnt = 0;
    	up = down = left = right = false;
    	if ((left = checkPit(x-1, y)) == false) cnt++;
    	if ((right = checkPit(x+1, y)) == false) cnt++;
    	if ((down = checkPit(x, y-1)) == false) cnt++;
    	if ((up = checkPit(x, y+1)) == false) cnt++;
    	
    	if (cnt == 3) {
    		if (left) declarePit(x-1, y);
    		if (right) declarePit(x+1, y);
    		if (down) declarePit(x, y-1);
    		if (up) declarePit(x, y+1);    		
    	}
    }
    
    private void sTag(int x, int y) {
    	boolean up, down, left, right;
    	up = down = left = right = false;
    	left = checkStench(x-1, y);
    	right = checkStench(x+1, y);
    	down = checkStench(x, y-1);
    	up = checkStench(x, y+1);
    	
    	if (left && right) declareWumpus(x, y);
    	else if (up && down) declareWumpus(x, y);
    	else if (left && up && checkNoWumpus(x-1, y+1)) declareWumpus(x, y);
    	else if (left && down && checkNoWumpus(x-1, y-1)) declareWumpus(x, y);
    	else if (right && up && checkNoWumpus(x+1, y+1)) declareWumpus(x, y);
    	else if (right && down && checkNoWumpus(x+1, y-1)) declareWumpus(x, y);
    }

	
	private boolean checkStench(int x, int y) {
		if (valid(x, y) && board[x][y].s == true)
			return true;
		return false;
	}
	
	private boolean checkNoWumpus(int x, int y) {
		if (valid(x, y) && board[x][y].w == 0)
			return true;
		else return false;
	}
	
	// mark board[x][y].p = 4;
	private void declarePit(int x, int y) {
		board[x][y].p = 4;
	}
	
	
	private void declareWumpus(int x, int y) {
		for(int i = 0; i < rightBoundary; i++)
			for (int j = 0; j < upBoundary; j++)
				board[i][j].w = 0;
			
		board[x][y].w = 4;
		return;		
	}
		
	// return false if invalid grid or no pit
	private boolean checkPit(int x, int y) {
		if (!valid(x, y))
			return false;
		// valid
		if (board[x][y].p == 0)
			return false;
		
		return true;		
	}
	
	
	// return false if invalid grid or no wumpus
	private boolean checkWumpus(int x, int y) {
		if (!valid(x, y))
			return false;
		// valid
		if (board[x][y].w == 0)
			return false;
		
		return true;
		
	}
	

    private boolean exploreAllButNoGold() {
        int x = pos.x;
        int y = pos.y;
        Queue<Pos> queue = new LinkedList<>();
        queue.offer(new Pos(x, y));
        boolean[][] visited = new boolean[SIZE][SIZE];
        visited[x][y] = true;
        while (!queue.isEmpty()) {
            Pos cur = queue.poll();
            int[][] dirs = {{0,1},{0,-1},{-1,0},{1,0}};
            for (int[] curDir : dirs) {
                x = cur.x + curDir[0];
                y = cur.y + curDir[1];
                if (x < 0 || x > rightBoundary || y < 0 || y > upBoundary)
                    continue;
                if (visited[x][y])
                    continue;
                Grid curGrid = board[x][y];
                if (curGrid == null)
                    return false;
                if (curGrid.w > 0 || curGrid.p > 0)
                    continue;
                if (curGrid.visited == 0)
                    return false;
                queue.offer(new Pos(x,y));
                visited[x][y] = true;
            }
        }
        return true;
    }

    private Action goHome() {
        if (pos.x == 0 && pos.y == 0) {
            return Action.CLIMB;
        }
        addToFrontier();
        return goToNextFrontier();
    }

    private Action grabGold() {
        int x = pos.x;
        int y = pos.y;
        Queue<Pos> queue = new LinkedList<>();
        queue.offer(new Pos(x, y));
        boolean[][] visited = new boolean[SIZE][SIZE];
        visited[x][y] = true;
        while (!queue.isEmpty()) {
            Pos cur = queue.poll();
            int[][] dirs = {{0,1},{0,-1},{-1,0},{1,0}};
            for (int[] curDir : dirs) {
                x = cur.x + curDir[0];
                y = cur.y + curDir[1];
                if (x < 0 || x > rightBoundary || y < 0 || y > upBoundary)
                    continue;
                if (visited[x][y])
                    continue;
                Grid curGrid = board[x][y];
                if (curGrid == null)
                    continue;
                if (curGrid.w > 0 || curGrid.p > 0)
                    continue;
                if (curGrid.visited == 0)
                    curGrid.visited = 49;
                if (curGrid.visited < 49)
                    curGrid.visited = 0;
                queue.offer(new Pos(x,y));
                visited[x][y] = true;
            }
        }
        return Action.GRAB;
    }


    private void clearInvalidPos() {
        Iterator<Pos> it = frontier.iterator();
        while (it.hasNext()) {
            Pos thisPos = it.next();
            int x = thisPos.x;
            int y = thisPos.y;
            if (x < 0 && y < 0 && x > rightBoundary && y > upBoundary) {
                it.remove();
            }
        }
    }
	
	private boolean valid(int x, int y) {
		if (x >= 0 && y >= 0 && x <= rightBoundary && y <= upBoundary)
			return true;
		else
			return false;
		
	}

    private void addToFrontier() {
        frontier.clear();
        int x;
        int y;
        if (dir == Dir.Up) {
            // up
            x = pos.x;
            y = pos.y + 1;
            if (x >= 0 && y >= 0 && x <= rightBoundary && y <= upBoundary) {
                frontier.offer(new Pos(x, y));
            }

            // left
            x = pos.x - 1;
            y = pos.y;
            if (x >= 0 && y >= 0 && x <= rightBoundary && y <= upBoundary) {
                frontier.offer(new Pos(x, y));
            }

            // right
            x = pos.x + 1;
            y = pos.y;
            if (x >= 0 && y >= 0 && x <= rightBoundary && y <= upBoundary) {
                frontier.offer(new Pos(x, y));
            }

            // down
            x = pos.x;
            y = pos.y - 1;
            if (x >= 0 && y >= 0 && x <= rightBoundary && y <= upBoundary) {
                frontier.offer(new Pos(x, y));
            }
        } else if (dir == Dir.Down) {

            // down
            x = pos.x;
            y = pos.y - 1;
            if (x >= 0 && y >= 0 && x <= rightBoundary && y <= upBoundary) {
                frontier.offer(new Pos(x, y));
            }

            // left
            x = pos.x - 1;
            y = pos.y;
            if (x >= 0 && y >= 0 && x <= rightBoundary && y <= upBoundary) {
                frontier.offer(new Pos(x, y));
            }

            // right
            x = pos.x + 1;
            y = pos.y;
            if (x >= 0 && y >= 0 && x <= rightBoundary && y <= upBoundary) {
                frontier.offer(new Pos(x, y));
            }

            // up
            x = pos.x;
            y = pos.y + 1;
            if (x >= 0 && y >= 0 && x <= rightBoundary && y <= upBoundary) {
                frontier.offer(new Pos(x, y));
            }
        } else if (dir == Dir.Left) {
            // left
            x = pos.x - 1;
            y = pos.y;
            if (x >= 0 && y >= 0 && x <= rightBoundary && y <= upBoundary) {
                frontier.offer(new Pos(x, y));
            }

            // up
            x = pos.x;
            y = pos.y + 1;
            if (x >= 0 && y >= 0 && x <= rightBoundary && y <= upBoundary) {
                frontier.offer(new Pos(x, y));
            }

            // down
            x = pos.x;
            y = pos.y - 1;
            if (x >= 0 && y >= 0 && x <= rightBoundary && y <= upBoundary) {
                frontier.offer(new Pos(x, y));
            }

            // right
            x = pos.x + 1;
            y = pos.y;
            if (x >= 0 && y >= 0 && x <= rightBoundary && y <= upBoundary) {
                frontier.offer(new Pos(x, y));
            }
        } else if (dir == Dir.Right) {
            // right
            x = pos.x + 1;
            y = pos.y;
            if (x >= 0 && y >= 0 && x <= rightBoundary && y <= upBoundary) {
                frontier.offer(new Pos(x, y));
            }

            // up
            x = pos.x;
            y = pos.y + 1;
            if (x >= 0 && y >= 0 && x <= rightBoundary && y <= upBoundary) {
                frontier.offer(new Pos(x, y));
            }

            // down
            x = pos.x;
            y = pos.y - 1;
            if (x >= 0 && y >= 0 && x <= rightBoundary && y <= upBoundary) {
                frontier.offer(new Pos(x, y));
            }

            // left
            x = pos.x - 1;
            y = pos.y;
            if (x >= 0 && y >= 0 && x <= rightBoundary && y <= upBoundary) {
                frontier.offer(new Pos(x, y));
            }
        }
    }

    private Action goToNextFrontier() {
        Iterator<Pos> it = frontier.iterator();
        int x;
        int y;
        Grid cur;
        while (it.hasNext()) {
            // remove dangerous destination
            Pos curPos = it.next();
            x = curPos.x;
            y = curPos.y;
            cur = board[x][y];
            if (cur != null) {
                if (!cur.isSafe()) {
                    it.remove();
                }
            }
        }
        Pos next = frontier.peek();

        List<Grid> list = new ArrayList<>();
        for (Pos curPos : frontier) {
            // find unvisited destination
            x = curPos.x;
            y = curPos.y;
            cur = board[x][y];
            if (cur == null) {
                continue;
            } else {
                list.add(cur);
            }
        }
        Collections.sort(list, new Comparator<Grid>() {
            @Override
            public int compare(Grid o1, Grid o2) {
                return o1.visited - o2.visited;
            }
        });

        Grid best = list.get(0);
        next = new Pos(best.x,best.y);

        if (next.y == pos.y + 1 && next.x == pos.x) {
            // up
            if (dir == Dir.Up) {
                pos.x = next.x;
                pos.y = next.y;
                return Action.FORWARD;
            } else if (dir == Dir.Down) {
                dir = Dir.Left;
                return Action.TURN_RIGHT;
            } else if (dir == Dir.Left) {
                dir = Dir.Up;
                return Action.TURN_RIGHT;
            } else if (dir == Dir.Right) {
                dir = Dir.Up;
                return Action.TURN_LEFT;
            } else {
                System.out.println("goToNextFrontier goUp is wrong");
                System.exit(-1);
            }
        } else if (next.y == pos.y - 1 && next.x == pos.x) {
            // down
            if (dir == Dir.Up) {
                dir = Dir.Right;
                return Action.TURN_RIGHT;
            } else if (dir == Dir.Down) {
                pos.x = next.x;
                pos.y = next.y;
                return Action.FORWARD;
            } else if (dir == Dir.Left) {
                dir = Dir.Down;
                return Action.TURN_LEFT;
            } else if (dir == Dir.Right) {
                dir = Dir.Down;
                return Action.TURN_RIGHT;
            } else {
                System.out.println("goToNextFrontier goDown is wrong");
                System.exit(-1);
            }
        } else if (next.x == pos.x - 1 && next.y == pos.y) {
            // left
            if (dir == Dir.Up) {
                dir = Dir.Left;
                return Action.TURN_LEFT;
            } else if (dir == Dir.Down) {
                dir = Dir.Left;
                return Action.TURN_RIGHT;
            } else if (dir == Dir.Left) {
                pos.x = next.x;
                pos.y = next.y;
                return Action.FORWARD;
            } else if (dir == Dir.Right) {
                dir = Dir.Down;
                return Action.TURN_RIGHT;
            } else {
                System.out.println("goToNextFrontier goLeft is wrong");
                System.exit(-1);
            }
        } else if (next.x == pos.x + 1 && next.y == pos.y) {
            // right
            if (dir == Dir.Up) {
                dir = Dir.Right;
                return Action.TURN_RIGHT;
            } else if (dir == Dir.Down) {
                dir = Dir.Right;
                return Action.TURN_LEFT;
            } else if (dir == Dir.Left) {
                dir = Dir.Up;
                return Action.TURN_RIGHT;
            } else if (dir == Dir.Right) {
                pos.x = next.x;
                pos.y = next.y;
                return Action.FORWARD;
            } else {
                System.out.println("goToNextFrontier goRight is wrong");
                System.exit(-1);
            }
        } else {
            System.out.println("goToNextFrontier is wrong");
            System.exit(-1);
        }
        return null;
    }


    // Grid describes the information about a grid
    // x, y are the coordinates of the grid, starting at 0
    // visited indicates whether this grid has been visited yet
    // w: 0 if be sure no wumpus, 1 if be possible to have a wumpus, 2 if certain there's no wumpus
    // p: 0 if be sure no pit, 1 if be possible to have a pit, 2 if certain there's no pit
    private class Grid {
        int x, y;
        int visited;
        int w, p;
        boolean s, b;
        boolean usedS, usedB;


        // constructor of Grid
        Grid() {
            x = 0;
            y = 0;
            visited = 0;
            w = -1;
            p = -1;
            s = false;
            b = false;
            usedS = false;
            usedB = false;
        }

        private boolean isSafe() {
            if (this.w == 0 && this.p == 0)
                return true;
            else
                return false;
        }

        @Override
        public String toString() {
            return "x:"+x+", y:"+y+", w:"+w+", p:"+p+", v:"+visited;
        }
    }
    // ======================================================================
    // YOUR CODE ENDS
    // ======================================================================
}